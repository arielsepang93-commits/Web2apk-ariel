const form=document.querySelector("#generator");
const status=document.querySelector("#status");

form.addEventListener("submit", async (e)=>{
  e.preventDefault();
  status.textContent="Mengirim build ke GitHub Actions...";

  const data=Object.fromEntries(new FormData(form).entries());

  try{
    const r=await fetch("/api/generate",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(data)
    });

    const result=await r.json();

    if(!r.ok) throw new Error(result.error || "Gagal");

    status.textContent=
      "Build berhasil dimulai.\n\n"+
      "Build ID: "+result.buildId+
      "\n\nTunggu GitHub Actions menyelesaikan build, lalu ambil APK dari GitHub Releases.";
  }catch(err){
    status.textContent="Gagal: "+err.message;
  }
});