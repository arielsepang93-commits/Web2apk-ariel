plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "${PACKAGE_NAME}"
    compileSdk = 35

    defaultConfig {
        applicationId = "${PACKAGE_NAME}"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "WEB_URL", "\"${WEB_URL}\"")
    }

    buildFeatures {
        buildConfig = true
    }
}