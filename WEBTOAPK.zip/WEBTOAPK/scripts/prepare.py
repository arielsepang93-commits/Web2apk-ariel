import sys
from pathlib import Path
import re

app_name, package_name, web_url, root = sys.argv[1:5]
root = Path(root)

if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)+", package_name):
    raise SystemExit("Invalid package name")

replacements = {
    "${APP_NAME}": app_name.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"',"&quot;"),
    "${PACKAGE_NAME}": package_name,
    "${WEB_URL}": web_url
}

for p in root.rglob("*"):
    if p.is_file():
        try:
            s=p.read_text()
        except UnicodeDecodeError:
            continue
        for a,b in replacements.items():
            s=s.replace(a,b)
        p.write_text(s)
